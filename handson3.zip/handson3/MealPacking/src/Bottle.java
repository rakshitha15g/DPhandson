
public class Bottle implements Packing {

	@Override
	public String pack() {
		// TODO Auto-generated method stub
		return "Bottle";
	}

}
