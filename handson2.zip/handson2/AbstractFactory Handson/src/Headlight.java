
public abstract class Headlight {

}
