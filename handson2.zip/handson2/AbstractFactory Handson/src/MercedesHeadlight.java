
public class MercedesHeadlight extends Headlight {

}
